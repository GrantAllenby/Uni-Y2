window.addEventListener('load', function () {
    "use strict";

    const l_form = document.getElementById('orderForm'); // F1 get a reference to the form
    l_form.CheckValue.onclick = calculateTotal; // F2 onclick event handler for CheckValue

    //l_form.onchange = calculateTotal; // J2 - would uncomment this for the J2 onchange event handler and remove line 5
   	l_form.submit.onclick = checkForm; // check form on submit

	function calculateTotal() {
       	let l_total = 0; // F3 set running total variable to 0

       	const l_adverts = l_form.querySelectorAll('section.advert'); // F4 get an array of the advert
       	const l_advertsCount = l_adverts.length; // F4 get the length of the array

       	// F5 loop through the array of adverts
       	for (let t_i = 0; t_i < l_advertsCount; t_i++) {
			const t_advert = l_adverts[t_i]; // get the current advert in the loop
			const t_checkbox = t_advert.querySelector('input[data-value][type=checkbox]'); // F6 get the checkbox for the current advert in the loop

			// F8 - ADD code below here so that if a checkbox is clicked, the price (value) for the checkbox is added to the running total variable
			
		} //for

		l_form.total.value = l_total; // F9 display the total
    }

    // H validation
    function checkForm(_evt){
		alert("checking form");
		_evt.preventDefault();
    } //checkForm()

});